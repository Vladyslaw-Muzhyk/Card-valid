def luhn_algorithm(card_number):
    card_number = card_number.replace(" ", "")[::-1]
    total_sum = 0
    for i, digit in enumerate(card_number):
        if i % 2 == 1:
            digit = int(digit) * 2
            if digit > 9:
                digit -= 9
        total_sum += int(digit)
    return total_sum % 10 == 0

def validate_card(card_number):
    card_number = card_number.replace(" ", "")
    if not card_number.isdigit():
        return False
    if len(card_number) < 13 or len(card_number) > 19:
        return False
    return luhn_algorithm(card_number)

card_number = input("Введіть номер банківської карти: ")
if validate_card(card_number):
    print("Valid")
else:
    print("Invalid")
