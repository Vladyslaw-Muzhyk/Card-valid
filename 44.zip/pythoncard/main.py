import tkinter as tk

def luhn_algorithm(card_number):
    card_number = card_number.replace(" ", "")[::-1]
    total_sum = 0
    for i, digit in enumerate(card_number):
        if i % 2 == 1:
            digit = int(digit) * 2
            if digit > 9:
                digit -= 9
        total_sum += int(digit)
    return total_sum % 10 == 0

def validate_card(card_number):
    card_number = card_number.replace(" ", "")
    if not card_number.isdigit():
        return False
    if len(card_number) < 13 or len(card_number) > 19:
        return False
    return luhn_algorithm(card_number)

def validate_and_display():
    card_number = entry.get()
    if validate_card(card_number):
        result_label.config(text="Valid")
    else:
        result_label.config(text="Invalid")

root = tk.Tk()
root.title("verification card number")

frame = tk.Frame(root)
frame.pack(padx=50, pady=50)

label = tk.Label(frame, text="enter the bank card number")
label.grid(row=0, column=0, sticky="w")

entry = tk.Entry(frame)
entry.grid(row=0, column=1, padx=10)

validate_button = tk.Button(frame, text="Перевірити", command=validate_and_display)
validate_button.grid(row=1, columnspan=2, pady=10)

result_label = tk.Label(frame, text="")
result_label.grid(row=2, columnspan=2)

root.mainloop()
